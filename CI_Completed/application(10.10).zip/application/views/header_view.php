<head>
  <meta charset="utf-8">

  <meta name="description" content="换车吧，基于二度人脉的二手车交易平台"/>
  <title>换车吧</title>

  <link rel="stylesheet" href="<?php echo base_url().'assets/'; ?>css/base.css">
  <link rel="stylesheet" href="<?php echo base_url().'assets/'; ?>css/car.css">

  <link rel="stylesheet" href="<?php echo base_url().'assets/'; ?>css/superfish.css" media="screen">
  <script src="<?php echo base_url().'assets/'; ?>js/jquery-1.11.1.js"></script>
  <script src="<?php echo base_url().'assets/'; ?>js/superfish.js"></script>
  <script src="<?php echo base_url().'assets/'; ?>js/jquery.touchslider.js"></script>

</head>

<body>

<div class="nav">
<ul class="sf-menu adjust" id="example">
  <li class="current level1">
    <a href="<?php echo  BASE_URL?>user_side/home">首页</a>
  </li>
  <li class="level1">
    <a href="<?php echo  BASE_URL?>user_side/searchNotice">价格</a>
    <ul>
      <li class="level2">
        <a href="<?php echo  BASE_URL?>user_side/searchNotice">0-5万</a>
      </li>
      <li class="level2">
        <a href="<?php echo  BASE_URL?>user_side/category/list_by_price_b">5-10万</a>
      </li>
      <li class="level2">
        <a href="<?php echo  BASE_URL?>user_side/category/list_by_price_c">10-20万</a>
      </li>
      <li class="level2">
        <a href="<?php echo  BASE_URL?>user_side/category/list_by_price_d">20-50万</a>
      </li>
      <li class="level2">
        <a href="<?php echo  BASE_URL?>user_side/category/list_by_price_e">50万以上</a>
      </li>
    </ul>
  </li>
  <li class="level1">
    <a href="<?php echo  BASE_URL?>user_side/category/list_by_price_a">里程</a>
    <ul>
      <li class="level2">
        <a href="<?php echo  BASE_URL?>user_side/category/list_by_run_distance_a">1-5万公里</a>
      </li>
      <li class="level2">
        <a href="<?php echo  BASE_URL?>user_side/category/list_by_run_distance_b">5-8万公里</a>
      </li>
      <li class="level2">
        <a href="<?php echo  BASE_URL?>user_side/category/list_by_run_distance_c">8-10万公里</a>
      </li>
      <li class="level2">
        <a href="<?php echo  BASE_URL?>user_side/category/list_by_run_distance_d">10-20万公里</a>
      </li>
    </ul>
  </li>
  <li class="level1">
    <a href="<?php echo  BASE_URL?>user_side/category/list_by_price_a">地区</a>
    <ul>
      <li class="level2">
        <a href="<?php echo  BASE_URL?>user_side/category/list_by_region_a">杭州本地</a>
      </li>
      <li class="level2">
        <a href="<?php echo  BASE_URL?>user_side/category/list_by_region_b">浙江省内</a>
      </li>
      <li class="level2">
        <a href="<?php echo  BASE_URL?>user_side/category/list_by_region_c">其它省份</a>
      </li>
    </ul>
  </li> 
</ul>
</div>