<html>
<head>
<title>Upload Form</title>
</head>
<body>

<?php //e//cho $src= $body["imageUrl"];?>

<br />
<img  src= 'http://localhost/upload/compressed_image/Galileo.png' alt="Galileo.png">
<p><?php echo anchor('/notice/publish', 'return'); ?></p>

</body>
</html>