<!DOCTYPE html>
<html>

<?php echo $header;?>
  
<div class="main">

<div class="head">
  
</div>

<div class="title">
<?php echo $title; ?>
</div>

<div class="date">
  发布时间：<?php echo date('Y-m-d');?>
  <?php echo nbs(3);?>
</div>


<div class="touchslider" style="z-index:0;">
  <div class="touchslider-viewport" style="width:100%;overflow:hidden;z-index:0">

    <?php foreach ($img_list as $img):?>

      <div class="touchslider-item" width="100%" style="z-index:0;">
        <img class="adjust" id="category" src="<?php echo $img; ?>" width="100%"  
        alt="对不起，您要查看的图片不存在！">
      </div>

    <?php endforeach; ?>

  </div>
</div>

<!-- <hr/> -->

<div class="date">
  车主：<?php echo $username;?>
  <?php echo nbs(3);?>
</div>

<div class="price">
  预售价格：
  <strong id="price">
    ￥<?php echo $price;?>
  </strong>
    万
</div>

<div class="price">
  新车价：
  <strong id="market_price1">
    <?php echo $market_price;?>
  </strong>
    万 (含购置税) 为您节省：
  <strong id="market_price2">
    <?php echo $market_price-$price;?>
  </strong>
    万
</div>

  <!-- 车辆信息 -->

<div class="info">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <thead>
      <td align="center">
        上牌时间
      </td>
      <td align="center">
        行驶里程
      </td>
      <td align="center">
        车牌号
      </td>
      <td align="center">
        变速箱
      </td>
    </thead>
    <tbody>
    <tr>
      <td align="center">
        <?php echo $registration_time; ?>
      </td>
      <td align="center">
        <?php echo $mileage; ?> 万公里
      </td>
      <td align="center">
        <?php echo $car_number; ?>
      </td>
      <td align="center">
        <?php echo $speed_box; ?>
      </td>
    </tr>
    </tbody>
  </table>
</div>

<div style="text-indent:0.2em;font-weight:bold;font-size:0.3em;height:2em;line-height:2em;">
  <!-- <strong> -->
  车辆简介
  <!-- </strong> -->
</div>

<div style="background-color:#ffffff;">
  <p style="text-indent:1.8em;font-size:0.3em;line-height:2.2em;margin-left:0.4em;margin-right:0.4em;">
    <?php echo $content; ?>
  </p>
</div>

<div style="text-indent:0.2em;font-weight:bold;font-size:0.3em;height:2em;line-height:2em;">
  <!-- <strong> -->
  配置情况
  <!-- </strong> -->
</div>

<?php 
  if (isset($configuration))
  {
    $configs = explode(',', $configuration);
  }
  else
  {
    $configs = array();
  }
?>

<?php foreach($configs as $config):?>
<div class="configuration">
  <img src="<?php echo base_url().'assets/configuration/'.$config.'1.png'; ?>"/>
</div>
<?php endforeach; ?>

<div style="width:100%;float:left;margin-top:2em;">
  <form action="<?php echo BASE_URL; ?>user_side/home">
    <textarea class="adjust" style="width:80%;height:12em;align:center;
    margin-left:10%;
    " value="ping"></textarea>
    <input type="submit" class="submit" name="submit" value="提交" style="float:right">
  </form>
</div>

<div style="width:100%;height:6em;float:left">
</div>

</div><!--End main div-->
<div class="footer">
  <a href="<?php echo BASE_URL; ?>user_side/home">
    <img src="<?php echo base_url().'assets/img/';?>icon_home.png" />
  </a>
</div>
</body>
<script type="text/javascript">

$(document).ready(function(){
  $("#price").css('font-size', '1.8em')
  $("#price").css('color', '#E9946C')

  $("#market_price1").css('font-size', '1.2em')
  $("#market_price1").css('color', '#E9946C')

  $("#market_price2").css('font-size', '1.2em')
  $("#market_price2").css('color', '#E9946C')
});


window.onload = function() {
    $(".touchslider").touchSlider()

    baseWindowWidth = $(window).width();
    num = baseWindowWidth / 80
    num = Math.floor(num)
    width = 100 / num + '%'
    $('.configuration').css('width', width)

    margin_right = baseWindowWidth * 0.1
    $('.submit').css('margin-right', margin_right)
  }
</script>

</html>