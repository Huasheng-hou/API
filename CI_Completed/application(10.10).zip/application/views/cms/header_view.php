<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>微信后台管理系统</title>
<!--                       CSS                       -->
<!-- Reset Stylesheet -->
<link rel="stylesheet" href="<?php echo base_url()?>assets/cms/css/reset.css" type="text/css" media="screen" />
<!-- Main Stylesheet -->
<link rel="stylesheet" href="<?php echo base_url()?>assets/cms/css/style.css" type="text/css" media="screen" />
<!-- Invalid Stylesheet. This makes stuff look pretty. Remove it if you want the CSS completely valid -->
<link rel="stylesheet" href="<?php echo base_url()?>assets/cms/css/invalid.css" type="text/css" media="screen" />
<!--                       Javascripts                       -->
<!-- jQuery -->
<script type="text/javascript" src="<?php echo base_url()?>assets/cms/scripts/jquery-1.3.2.min.js"></script>
<!-- jQuery Configuration -->
<script type="text/javascript" src="<?php echo base_url()?>assets/cms/scripts/simpla.jquery.configuration.js"></script>
<!-- Ajax Upload -->
<script type="text/javascript" src="<?php echo base_url('assets/cms/scripts/ajaxupload.js')?>"></script>