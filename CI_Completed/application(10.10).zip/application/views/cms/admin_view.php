
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php echo $header; ?>
</head>
<body>
<div id="body-wrapper">
  <!-- Wrapper for the radial gradient background -->
  <div id="sidebar">
    <?php echo $sidebar?>
  </div>
  <!-- End #sidebar -->
  <div id="main-content">
    <!-- Main Content Section with everything -->
    <noscript>
    <!-- Show a notification if the user has disabled javascript -->
    <div class="notification error png_bg">
      <div> Javascript is disabled or is not supported by your browser. Please <a href="http://browsehappy.com/" title="Upgrade to a better browser">upgrade</a> your browser or <a href="http://www.google.com/support/bin/answer.py?answer=23852" title="Enable Javascript in your browser">enable</a> Javascript to navigate the interface properly.
        Download From <a href="http://www.exet.tk">exet.tk</a></div>
    </div>
    </noscript>
    <!-- Page Head -->
    <h2>欢迎！</h2>
    <p id="page-intro">你想做什么？</p>
    <ul class="shortcut-buttons-set">
      <li><a class="shortcut-button" href="<?php echo CMS_BASE_URL.'admin/edit_article'?>">
        <span> <img src="<?php echo base_url()?>assets/cms/images/icons/pencil_48.png" alt="icon" /><br />
        新增信息 
        </span>
      </a></li>
      <li><a class="shortcut-button" href="<?php echo CMS_BASE_URL.'admin/display_articles'?>">
        <span> <img src="<?php echo base_url()?>assets/cms/images/icons/paper_content_pencil_48.png" alt="icon" /><br />
        管理信息 
        </span>
      </a></li>
    </ul>
    <!-- End .shortcut-buttons-set -->
    <div class="clear"></div>
    <!-- End .clear -->
    <?php echo $footer; ?>
    <!-- End #footer -->
  </div>
  <!-- End #main-content -->
</div>
</body>
<!-- Download From www.exet.tk-->
</html>
