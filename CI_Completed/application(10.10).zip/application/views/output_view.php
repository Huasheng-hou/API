
<html>
<head>
<title>Upload Form</title>
</head>
<body>


<pre><?php 
;
var_dump(json_encode($this->output->res->head));
var_dump(json_encode($this->output->res->body));
?>
</pre>


</form>

</body>
</html>