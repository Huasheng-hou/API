<!DOCTYPE html>
<html>

<?php echo $header; ?>

<div class="main">

<div class="head">
</div>

<div class="body">

<?php foreach ($article_list as $article): ?>

<div class="article_container adjust">

  <?php
    $img    = $article['img_list'][0];
    var_dump($img);
  ?>

  <div class="pic_container" >
    <a href="<?php echo BASE_URL.'user_side/detail/index/'.$article['uid']; ?>">
    <img class="adjust" id="category" src="<?php echo $img; ?>"/>

    </a>
  </div>

  <div class="right_container">
    <div class="title">
      <?php echo $article['title']; ?>
    </div>

    <div class="price_container">
      
      <strong class="price">
        ￥<?php echo $article['price'];?>万
      </strong>
      <strong class="market_price">
        省 <?php echo $article['market_price']-$article['price'];?>万
      </strong>
    </div>

    <div class="seller_info">
      <?php echo $article['username'];?>
      |
     <!--  <?php 
        // $region = explode(' ' ,$article['region']);

        // if (null != $region[1])
        // {
        //   echo $region[1];
        // }
        // if (null != $region[2])
        // {
        //   echo ' ';
        //   echo $region[2];
        // }
      ?> -->
    </div>

  </div>

  <div class="info">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <thead>
      <td align="center">
        上牌时间
      </td>
      <td align="center">
        <span class="sp-y">
          行驶里程
        </span>
      </td>
      <td align="center">
        <span class="sp-y">
          车牌号
        </span>
      </td>
      <td align="center">
        变速箱
      </td>
    </thead>
    <tbody>
    <tr>
      <td align="center">
        <?php echo $article['registration_time']; ?>
      </td>
      <td align="center">
        <?php echo $article['mileage']; ?> 万公里
      </td>
      <td align="center">
        <?php echo $article['car_number']; ?>
      </td>
      <td align="center">
        <?php echo $article['speed_box']; ?>
      </td>
    </tr>
    </tbody>
    </table>
  </div>

</div>

<?php endforeach; ?>
<div><!--End body div-->

<div class="footer">
  <a href="<?php echo BASE_URL; ?>user_side/home">
    <img src="<?php echo base_url().'assets/img/';?>icon_home.png" />
  </a>
</div>

</div><!--End main div-->
</body>

<script type="text/javascript">

  $(document).ready(function(){

    $(".price").css('font-size', '1.8em')
    $(".price").css('color', '#E9946C')

    $(".market_price").css('color', '#E9946C')

  });

</script>
<script type="text/javascript">
window.onload = function () {
  setBase()
  adjustWindow();
}

$(window).resize(function () {
  adjustWindow();
});

function adjustWindow()
{
  baseWindowWidth
    var currentWidth = $(window).width();

    $('.adjust').each(
      function(index){
//        alert($(this).width())
//                alert($(this).attr('baseWidth'))
//                alert(currentWidth)
// alert(index)
        $width = $(this).attr('baseWidth')/baseWindowWidth * currentWidth;
        $height = $(this).attr('baseheight')/baseWindowWidth * currentWidth;
        $(this).width($width);
        $(this).height($height);

      }
    )
}

function setBase(){

  baseWindowWidth = $(window).width();


  $('.adjust').each(
    function(index){
      $width  = $(this).width();
      $height = $(this).height();

      $(this).attr('baseWidth',$width);
      $(this).attr('baseHeight',$height);
    }
  )
}

</script>

</html>