<!DOCTYPE html>
<html>

<?php echo $header; ?>

<div class="main">

  <div class="head"></div>

<div class="body">

<?php foreach ($article_list as $article):?>

<?php

  $img = $article['img_list'][0];

?>

<div class="box adjust">

  <a href="<?php echo BASE_URL.'user_side/detail/index/'.$article['nid']; ?>">
    <img class="adjust" id="home" src="<?php echo $img; ?>"/>
  </a>
</div>

<?php endforeach;?>

</div><!--End div body-->

<div class="footer">
	<a href="<?php echo BASE_URL; ?>user_side/home">
		<img src="<?php echo base_url().'assets/img/';?>icon_home.png" />
	</a>
</div>

</div><!--End div main-->

</body>

</html>

<script type="text/javascript">
window.onload = function () {
  setBase()
  adjustWindow();
}

$(window).resize(function () {
  adjustWindow();
});

function adjustWindow()
{
  baseWindowWidth
    var currentWidth = $(window).width();

    $('.adjust').each(
      function(index){
//        alert($(this).width())
//                alert($(this).attr('baseWidth'))
//                alert(currentWidth)
// alert(index)
        $width = $(this).attr('baseWidth')/baseWindowWidth * currentWidth;
        $height = $(this).attr('baseheight')/baseWindowWidth * currentWidth;
        $(this).width($width);
        $(this).height($height);
      }
    )
}

function setBase(){

  baseWindowWidth = $(window).width();


  $('.adjust').each(
    function(index){
      $width  = $(this).width();

      $height = $(this).height();

      $(this).attr('baseWidth',$width);
      $(this).attr('baseHeight',$height);
    }
  )
}

</script>