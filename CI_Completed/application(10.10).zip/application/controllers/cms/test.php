<?php
class test extends CI_Controller
{
	function index()
	{
		var_dump(base_url());
	}

}
