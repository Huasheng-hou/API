<?php
class Fetch extends CI_Controller
{
	function __construct()
	{
		parent ::__construct();
		$this->load->library('spider/charlie');

	}

	function index()
	{

		$url = 'http://zj.hx2car.com/details/138113573';
		$charlie = new Charlie;

		$charlie->fetch($url);

		$charlie->getInfo();
		var_dump($charlie->web);
		var_dump($charlie->web->baseInfo);
		$baseInfo = $this->cut_str($charlie->web->baseInfo);
		var_dump($baseInfo);

	}

	function cut_str($str)
	{
		$str = str_replace('编号:','',$str);
		$str = str_replace('车型','',$str);
		$str = str_replace('里程','',$str);
		$str = str_replace('排放','',$str);
		$str = str_replace('排放','',$str);
		return $str;
	}
}