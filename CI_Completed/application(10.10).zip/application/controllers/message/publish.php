<?php 
class Publish extends MY_Controller
{
	function __construct()
	{
		parent ::__construct();


	}

	private function define()
	{
		
	}

}