<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Message_model extends CI_model
{
	function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->define();
	}

	function insert_message($destination_list,
							$title,							
							$content    ,
							$img_list = '[]'  								
					        )
	{
		$data = array(
					'title'       		=>$title,
					'destination_list'  =>$destination_list,
					'content'			=>$content,
					'img_list'			=>$img_list,
							
					'uid'		        =>$this->input->uid,
					'time'				=>$this->input->sysTime,
					'coordinate'		=>$this->input->coordinate					
				);
		 $this->db->insert($this->table, $data);
		$nid = $this->db->query("SELECT LAST_INSERT_ID()")->row_array();
		return $nid["LAST_INSERT_ID()"];

	}

	function get_message_list($pageNumber,$numberPerPage)
	{
		$messageNumber = ($pageNumber-1)*$numberPerPage;
		$this->db->order_by("time", "desc"); 
		$this->db->select("mid,
			               title       	,
			               destination_list,
						   content	,	
		 				   img_list	,			 				   		
		 				   uid	,	      
		 				   time	,		
						   coordinate "
						  );
		$query = $this->db->get($this->table, $numberPerPage, $messageNumber);		
		$messageList = $query->result_array();

		//$messageList = $this->update_img_list($messageList);

		return $messageList;
	}


	function get_message_detail($mid)
	{
		//$SQL = "SELECT `mid`, `title`, `destination_list, `content`, `time`, `counter_view`, `counter_follow`, `counter_praise`, `username`, `signature`, `avatar_url`";
		$SQL = "SELECT `mid`, `title`, `destination_list`, `content`, `time`";
		$SQL .=" FROM (`prefix_message`)";
		//$SQL .=	"JOIN `prefix_user` ON `uid` = `a_uid`",
		$SQL .=	"WHERE `mid` =  '".$mid."'"; 
		$query = $this->db->query($SQL);
		$this->messageDetail = $query->row_array();

		return $this->messageDetail;
	}
	// function update_img_list($messageList)
	// {
	// 	$i = 0;
	// 	foreach ($messageList as $value) 
	// 	{
	// 		$img_array   = explode(",", $value["img_list"]);
	// 		$messageList[$i]["img_list"] = $img_array;
	// 		$i = $i + 1;
	// 	}
	// 	return $messageList;
	// }

	function get_unread_message()
	{
		$this->db->select("mid,
						   content,
		 				   img_list,
		 				   destination_list,
		 				   uid,
		 				   time,
		 				   coordinate,
						   is_fetched" );
		$query = $this->db->get($this->table);		
		$messageList = $query->result_array();
		return $messageList;
	}

	function delete_message($mid)
	{
		$this->db->where('mid', $mid);
        $result = $this->db->delete($this->table);

        return $result;
	}

	function define()
	{
		; $this->table = 'prefix_message'
		; $this->colomn 
			= array(
					 'mid'
					,'content'
					,'img_list'
					,'destination_list'
					,'uid'
					,'time'
					,'coordinate'
					,'type'
					,'is_fetched'
					)
		;
	}
}


/*****

CREATE TABLE IF NOT EXISTS `prefix_message` (
  `mid` int(30) NOT NULL AUTO_INCREMENT,
  `title` varchar(512),
  `content` text,
  `img_list` varchar(512) DEFAULT NULL,
  `destination_list` varchar(512) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `coordinate` varchar(64) DEFAULT NULL,
  `type` varchar(32) DEFAULT NULL,
  `is_fetched` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`mid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
*/