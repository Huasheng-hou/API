<?php
// include 'Snoopy.class.php';
// include 'WaterMark.php';
// include 'Taoche.com.php';
// include 'TaochePhone.php';

// include 'Hx2car.com.php';
include 'Charlie.php';

$url = 'http://zj.hx2car.com/details/138113573';


class Insert
{
	function index()
	{
		$charlie = new Charlie;

		$charlie->fetch($url);

		$charlie->getInfo();
		var_dump($charlie->web);
	}
}